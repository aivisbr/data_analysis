---
name: scf-brand
description: Apply Scandic Fusion brand guidelines to all presentations and documents
---

## Overview
This Skill provides Scandic Fusion's official brand guidelines for creating consistent, professional materials. When creating presentations, documents, or marketing materials, apply these standards to ensure all outputs match Scandic Fusion's visual identity. Claude should reference these guidelines whenever creating external-facing materials or documents that represent Scandic Fusion.

## Brand Colors

Our official brand colors are:
- Primary: #2640AC
- Primary: #DFF7FF
- Primary: #00061E
- Secondary: #C8E6F4, #3B527F, #98A9D6
- Secondary: #BCB2A9, #005D3A, #9AAD61
- Secondary: #FBC1B1, #F4564F, #FB9047
- Secondary: #E5E5E5, #3A3A3A, #AEAEAE
- Accent: #FB432D

## Typography

Use Web-safe fonts: Space Grotesk and Inter.
Headings: Space Grotesk (with sans-serif fallback)
Body text: Inter (with sans-serif fallback)
Note: Fonts should be pre-installed in your environment for best results
Size guidelines:
- H1: 32pt, uppercase
- H2: 24pt, uppercase
- Body: 11pt

## Fonts

To get Space Grotesk and Inter fonts, use ttf files, or upload from the https://fonts.googleapis.com, or define this font in the pptx object:

- upload from the Google APIs:
```
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Space+Grotesk:wght@300..700&display=swap" rel="stylesheet">
```

```
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Space+Grotesk:wght@300..700&display=swap" rel="stylesheet">
```

- Define pptx object using `pptxgenjs` library:
```
const pptxgen = require('pptxgenjs');

const pptx = new pptxgen();

pptx.theme = {
  headFontFace: "Space Grotesk, sans-serif",
  bodyFontFace: "Inter, sans-serif"
};

```


## Logo Usage

Always use the logo on the #00061E or #2640AC background. Maintain minimum spacing of 0.5 inches around the logo. Resize the image proportionally.

## When to Apply

Apply these guidelines whenever creating:
- PowerPoint presentations
- Word documents for external sharing
- Marketing materials
- Reports for clients

## Assets

See the assets folder for logo file (scf_logo.svg), visual elements (red_vector.svg, blue_vector.svg) and font files (.ttf).